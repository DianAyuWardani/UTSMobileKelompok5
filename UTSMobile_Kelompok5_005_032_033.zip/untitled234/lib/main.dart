import 'package:flutter/material.dart';
import 'data/quiz_brain.dart';

void main() {
  runApp(const QuizApp());
}

class QuizApp extends StatelessWidget {
  const QuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz D4MI',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
      ),
      home: const StartScreen(),
    );
  }
}

class StartScreen extends StatelessWidget {
  const StartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.greenAccent.shade100,
      appBar: AppBar(
        title: const Text('QUIZ PENGETAHUAN PRODI'),
        centerTitle: true,
        backgroundColor: Colors.blue.shade200,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Selamat Datang di Quiz D4 MANAJEMEN INFORMATIKA!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const QuizPage()),
                );
              },
              icon: const Icon(Icons.play_arrow),
              label: const Text('Mulai Quiz'),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.exit_to_app),
              label: const Text('Keluar'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final QuizBrain _quizBrain = QuizBrain();
  int _score = 0;
  bool _isFinished = false;
  String _feedbackMessage = '';
  bool _showFeedback = false;

  void _answerQuestion(bool userAnswer) {
    bool correct = _quizBrain.getQuestionAnswer();
    if (userAnswer == correct) {
      _score += 10;
      _feedbackMessage = 'Jawaban Benar!';
    } else {
      _feedbackMessage = 'Jawaban Salah!';
    }

    setState(() {
      _showFeedback = true;
    });

    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _showFeedback = false;
        if (_quizBrain.isFinished()) {
          _isFinished = true;
        } else {
          _quizBrain.nextQuestion();
        }
      });
    });
  }

  void _resetQuiz() {
    setState(() {
      _score = 0;
      _isFinished = false;
      _quizBrain.reset();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_isFinished) {
      return Scaffold(
        backgroundColor: Colors.greenAccent.shade100,
        appBar: AppBar(
          title: const Text('Hasil Quiz'),
          centerTitle: true,
          backgroundColor: Colors.blue.shade200,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Skor kamu: $_score / 100',
                style: const TextStyle(fontSize: 22),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _resetQuiz,
                child: const Text('Ulangi Quiz'),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Kembali ke Menu'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.greenAccent.shade100,
      appBar: AppBar(
        title: const Text('Quiz D4MI'),
        centerTitle: true,
        backgroundColor: Colors.blue.shade200,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _quizBrain.getQuestionText(),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            if (_showFeedback)
              Text(
                _feedbackMessage,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: _feedbackMessage == 'Jawaban Benar!' ? Colors.green : Colors.red,
                ),
              ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _showFeedback ? null : () => _answerQuestion(true),
              child: const Text('BENAR'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _showFeedback ? null : () => _answerQuestion(false),
              child: const Text('SALAH'),
            ),
          ],
        ),
      ),
    );
  }
}
