class Question {
  final String questionText;
  final bool questionAnswer;

  Question({required this.questionText, required this.questionAnswer});
}
