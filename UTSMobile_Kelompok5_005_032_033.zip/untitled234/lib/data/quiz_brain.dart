import '../models/question.dart';

class QuizBrain {
  int _questionNumber = 0;

  // Menggunakan _questionBank untuk variabel privat
  final List<Question> _questionBank = [
    Question(
      questionText: 'UI dalam konteks desain aplikasi adalah User Interface',
      questionAnswer: true,
    ),
    Question(
      questionText: 'Manajemen Informatika adalah ilmu tentang periklanan online',
      questionAnswer: false,
    ),
    Question(
      questionText: 'DBMS adalah software untuk mengelola basis data',
      questionAnswer: true,
    ),
    Question(
      questionText: 'MySQL adalah salah satu jenis DBMS yang sering digunakan',
      questionAnswer: true,
    ),
    Question(
      questionText: 'Information Security adalah istilah untuk keamanan sistem informasi',
      questionAnswer: true,
    ),
    Question(
      questionText: 'Fungsi utama analisis sistem adalah menjual sistem ke klien',
      questionAnswer: false,
    ),
    Question(
      questionText: 'Sistem informasi berbasis komputer membuat pekerjaan menjadi lebih lama',
      questionAnswer: false,
    ),
    Question(
      questionText: 'Java sering digunakan untuk pengembangan aplikasi manajemen',
      questionAnswer: true,
    ),
    Question(
      questionText: 'Big Data merujuk pada jumlah data yang sangat besar dan kompleks',
      questionAnswer: true,
    ),
    Question(
      questionText: 'Unit Testing adalah pengujian yang fokus pada fungsi secara terpisah',
      questionAnswer: true,
    ),
  ];

  // Fungsi untuk lanjut ke soal berikutnya
  void nextQuestion() {
    if (_questionNumber < _questionBank.length - 1) {
      _questionNumber++;
    }
  }

  // Mendapatkan teks soal berdasarkan nomor soal
  String getQuestionText() {
    return _questionBank[_questionNumber].questionText;
  }

  // Mendapatkan jawaban soal berdasarkan nomor soal
  bool getQuestionAnswer() {
    return _questionBank[_questionNumber].questionAnswer;
  }

  // Mengecek apakah soal sudah selesai (terakhir)
  bool isFinished() {
    return _questionNumber >= _questionBank.length - 1;
  }

  // Mengatur ulang nomor soal ke awal
  void reset() {
    _questionNumber = 0;
  }

  // Getter untuk nomor soal yang sedang ditanyakan
  int get questionNumber => _questionNumber;

  // Getter untuk total jumlah soal
  int get totalQuestions => _questionBank.length;
}
